<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Formularios</title>
  
  <?php
$tema = "claro";

if (isset($_GET['tema'])) {
  if ($_GET['tema'] == "escuro") {
    $tema = "bootstrap-dark";
    echo '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-dark-5@1.1.3/dist/css/bootstrap-dark.min.css">';
  } else {
    echo '<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">';
    $tema = "bootstrap";
  }
}
?>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>



<body class="<?=$tema?>">
<?php 
  include('header.php');
?>
  <h1>Aluno</h1>
  
  <form method="POST">
  <div class="form-group row">
    <label for="nome" class="col-2 col-form-label">Nome</label> 
    <div class="col-10">
      <input id="nome" name="nome" placeholder="Digite o seu nome" type="text" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label for="idade" class="col-2 col-form-label">Idade</label> 
    <div class="col-10">
      <input id="idade" name="idade" placeholder="Digite sua idade" type="text" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label for="genero" class="col-2 col-form-label">Genero</label> 
    <div class="col-10">
      <select id="genero" name="genero" class="custom-select">
        <option value="M">Masculino</option>
        <option value="F">Feminino</option>
      </select>
    </div>
  </div> 
  <div class="form-group row">
    <div class="offset-2 col-10">
      <button name="submit" type="submit" class="btn btn-primary">Enviar</button>
    </div>
  </div>
</form>
<?php

if (isset($_POST["nome"]) && $_POST["nome"] <> "") {

  $nome = $_POST["nome"];
  $idade = $_POST["idade"];
  $sexo = "";
  if (isset($_POST["genero"]) && $_POST["genero"] === "M"){
    $sexo = "Masculino";
    // header("Location: curso.php");
  } else {
    $sexo = "Feminino";
    // header("Location: professor.php");
  }

?>
<h3>Nome: <?php echo $nome;?></h3>
<h3>Idade:<?=$idade?></h3>
<h3>Genero: <?php echo $sexo;?>
<?php 
} else {
  echo "<h3>Preencha o formulario</h3>";
}
?>
</body>
</html>