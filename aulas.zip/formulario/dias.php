<?php 

$dia = 1;
$diaExtenso = "Domingo";
if(isset($_GET["dia"])){
  $dia = (int) $_GET["dia"];

  switch ($dia) {
    case 1:
      $diaExtenso = "Domingo";
      break;
    case 2:
      $diaExtenso = "Segunda-feira";
      break;
    case 3:
      $diaExtenso = "Terça-feira";
      break;
    case 4:
      $diaExtenso = "Quarta-feira";
      break;
    case 5:
      $diaExtenso = "Quinta-feira";
      break;
    case 6:
      $diaExtenso = "Sexta-feira";
      break;
    case 7:
      $diaExtenso = "Sabado";
      break;
    default:
      $diaExtenso = "Dia invalido";
      break;

  }

  
}
echo "<h1>".$diaExtenso."</h1>";

?>
