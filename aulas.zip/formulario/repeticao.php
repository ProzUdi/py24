<?php
$i = 0;

while ($i < $qtd){
  echo '<input type="text" name="nome_'.$i.'">';
}
echo "</ul>";


for($i = 0; $i<=10; $i++){
  echo $i."<br>";
}

$nomes = array("Marco", "Kawan", "Rafael", "Caroline", "Clara");

foreach ($nomes as $nome ) {
  echo $nome."<br>";
  if ($nome == "Rafael") {
    continue;
  }
  echo "Nomes:".$nome."<br>";
}

?>