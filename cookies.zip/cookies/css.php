<style>
  <?php
    $bk = "#002A52";
    $text = "#702700";
    if (isset($_COOKIE["background"])) {
      $bk = $_COOKIE["background"];
    }
    if (isset($_COOKIE["text"])) {
      $text = $_COOKIE["text"];
    }
  ?>
  a, a:focus, a:active{
    color: <?=$text?>;
  }
  body {
    background: <?=$bk?>;
    color: <?=$text?>;
  }
</style>