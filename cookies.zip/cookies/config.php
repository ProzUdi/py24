<?php 
    $bk = "#002A52";
    $text = "#702700";

    if (isset($_COOKIE["background"])) {
      $bk = $_COOKIE["background"];
    }

    if (isset($_COOKIE["text"])) {
      $text = $_COOKIE["text"];
    }

    if(isset($_POST['background']) && isset($_POST['text'])) {
      setcookie("background",$_POST['background'], time() + 3600, '/');
      setcookie("text",$_POST['text'], time() + 3600, '/');
      $bk = $_POST["background"];
      $text = $_POST["text"];
    }
?>

  <h1>Configure seu site</h1>
  <form method="POST">
    <label for="background">Cor de fundo</label>
    <input id="background" name="background" type="color" value="<?=$bk?>">
    <label for="text">Cor do texto</label>
    <input id="text" name="text" type="color" value="<?=$text?>">
    <button type="submit">Atualizar</button>
  </form>
</body>
</html>