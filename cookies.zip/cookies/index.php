<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cookies</title>
</head>
<?php include('css.php');?>
<body>
  <h1> Aprendendo sobre cookies</h1>
  <a href="config.php">Configurar cookies</a>
  
</body>
</html>