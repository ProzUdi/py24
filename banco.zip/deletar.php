<?php
if (isset($_GET["id"]) && $_GET["id"] != "") {
    $codigo = $_GET["id"];

    include_once "conexao.php";

    $sql = "delete from cliente where codigo=$codigo";
    $result = mysqli_query($conn, $sql);

    header("Location: index.php");

} else {
    echo "Informe o registro para deletar";
}

?>