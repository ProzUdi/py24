<?php
if (isset($_POST["nome"]) && $_POST["nome"] != "") {
    $nome = $_POST["nome"];
    $idade = $_POST["idade"];
    include_once "conexao.php";
    
    $sql = "insert into cliente (nome, idade) values ('$nome', $idade)";
    $result = mysqli_query($conn, $sql);

    header("Location: index.php");

} else {
    echo "Preencha os dados";
}

?>