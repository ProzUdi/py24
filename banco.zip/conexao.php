<?php 
$server = "localhost";
$user = "root";
$password = "";
$dbname = "loja";

$conn = mysqli_connect($server, $user, $password, $dbname);
?>