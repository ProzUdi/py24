<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clientes</title>
</head>
<body>
    <a href="adicionar.php">Adicionar</a>
    <?php
       include_once "conexao.php";

        $sql = "select * from cliente";
        $result = mysqli_query($conn, $sql);

        while ($linha = mysqli_fetch_array($result )){
            $nome = $linha["nome"];
            $idade = $linha["idade"];
            $codigo = $linha["codigo"];
            echo "<br><br>Nome: $nome <br> Idade: $idade <br> Codigo: $codigo";
            echo "<br><a href='editar.php?id=$codigo'>Editar</a>";
            echo "<br><a href='deletar.php?id=$codigo'>Deletar</a>";
            
        }

    ?>
</body>
</html>	