<?php

       include_once "conexao.php";
        if (isset($_POST["codigo"]) && $_POST["codigo"] != "") {
          $codigo = $_POST["codigo"];
          $nome = $_POST["nome"];
          $idade = $_POST["idade"];
          $sql = "update cliente set nome='$nome', idade='$idade' where codigo='$codigo'";
          echo $sql;
          $result = mysqli_query($conn, $sql);

          header("Location: index.php");
          
        }
        ?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar</title>
</head>
<body>
    <a href="index.php">Lista</a>
    <a href="adicionar.php">Adicionar</a>
    <?php
    if (isset($_GET["id"]) && $_GET["id"] != "") {
        
        $codigo = $_GET["id"];
        $sql = "select * from cliente where codigo=$codigo";
        $result = mysqli_query($conn, $sql);

        $linha = mysqli_fetch_array($result );
        if (isset($linha["nome"])){
          $codigo = $linha["codigo"];
          $nome = $linha["nome"];
          $idade = $linha["idade"];
          ?>
          <form method='post' action='editar.php'>
            Codigo: <input type='text' name='codigo' readonly disable value='<?=$codigo?>'/>
            Nome: <input type='text' name='nome' placeholder='Digite seu nome' value='<?=$nome?>'/>
            Idade: <input type='number' name='idade'placeholder='Digite sua idade' value='<?=$idade?>' />
            <button type='submit'>Enviar</button>
          </form>
          <?php

        } else {
          echo "Registro não encontrado";
        }
            
        

      } else {
        echo "informe um id para editar";
      }

    ?>
</body>
</html>	