<?php 
  include 'header.php'; 
  require('auth.php');
 ?>
  <h1>Turnos</h1>
  
  <form method="POST">
  <div class="form-group row">
    <label for="nome" class="col-2 col-form-label">Nome</label> 
    <div class="col-10">
      <input id="nome" name="nome" placeholder="Digite o seu nome" type="text" class="form-control">
    </div>
  </div>
  
  <div class="form-group row">
    <label for="turnos" class="col-2 col-form-label">Turnos</label> 
    <div class="col-10">
      <input id="turnos" name="turnos" placeholder="Digite os Turnos" type="text" class="form-control">
    </div>
  </div> 
  <div class="form-group row">
    <div class="offset-2 col-10">
      <button name="submit" type="submit" class="btn btn-primary">Enviar</button>
    </div>
  </div>
</form>
<?php
  if (isset($_POST["nome"]) && $_POST["nome"] <> "") {
    $nome = $_POST["nome"];
    $turnos = $_POST["turnos"];
?>
<h3>Nome: <?php echo $nome;?></h3>
<h3>Turnos: <?php echo $turnos;?>
<?php 
} else {
  echo "<h3>Preencha o formulario</h3>";
}
?>
</body>
</html>