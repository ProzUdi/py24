<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Formularios</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
  <h1>Página Inicial</h1>
  <form method="POST">
  <div class="form-group row">
    <label for="usuario" class="col-2 col-form-label">Usuario</label> 
    <div class="col-10">
      <input id="usuario" name="usuario" required placeholder="Digite o seu usuário" type="text" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label for="senha" class="col-2 col-form-label">Senha</label> 
    <div class="col-10">
      <input id="senha" name="senha" placeholder="Digite sua senha" required type="password" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <div class="offset-2 col-10">
      <button name="submit" type="submit" class="btn btn-primary">Enviar</button>
    </div>
  </div>
</form>
<?php 
  if (isset($_POST["usuario"]) && isset($_POST["senha"])) {
    $usuario = $_POST["usuario"];
    $senha = $_POST["senha"];
    if ($usuario === "" || $senha === "") {
      echo "<h3>Login e senha obrigatórios</h3>";
    } else {
      if ($usuario === "dielson" && $senha === '123'){
        session_start();
        $_SESSION['isLogado'] = true;
        $_SESSION['nome'] = "Dielson";
        header("Location: aluno.php");
      } else {
        echo "<h3>Login invalido</h3>";
      }
    }

  }
?>
</body>
</html>