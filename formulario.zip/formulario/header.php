<nav class="nav nav-pills nav-justified">
  <a class="nav-item nav-link" href="index.php">Pagina Inicial</a>
  <a class="nav-item nav-link" href="aluno.php">Aluno</a>
  <a class="nav-item nav-link" href="professor.php">Professor</a>
  <a class="nav-item nav-link" href="curso.php">Curso</a>
</nav>